---
name: sleeper-fantasy-assistant
description: >-
  Analyzes Sleeper fantasy football leagues to identify roster cloggers, find waiver wire additions, and recommend rookie draft picks based on team needs and consensus rankings.
---

# Sleeper Fantasy Assistant

## Overview
This skill allows agents to seamlessly analyze any Sleeper fantasy football league. By extracting roster limits, positional values, and the active player pool from the Sleeper API, it uses a custom "ADDS" algorithm (Age, Draft Capital, Depth Chart, Status) combined with Sleeper Consensus Ranks to identify which players are "Liabilities" (roster cloggers). It then searches the waiver wire for superior options or analyzes active rookie drafts to provide the best possible draft pick for a specific team.

## Dependencies
- None! Pure Python 3 standard library.

## Quick Start
To get waiver wire advice for a specific league:
```bash
python3 ~/.gemini/config/skills/sleeper-fantasy-assistant/scripts/fantasy_cli.py find-waivers \
  --user-id p4t0b4ll3rs \
  --league-id 1312486140195917824 \
  --output waivers_result.json
```

## Utility Scripts

The skill uses a robust Python script at `scripts/fantasy_cli.py` to handle all Sleeper API interaction, caching, and rate-limiting.

### `find-waivers`
Analyzes the roster of the specified user in the specified league, identifies drop candidates ("Liabilities"), and proposes better options from the available free agent pool.
**Arguments:**
- `--user-id`: The Sleeper User ID or Username (e.g., `p4t0b4ll3rs`)
- `--league-id`: The specific League ID (if known). If omitted, the script will list available leagues.
- `--output`: Required. Where to save the JSON output.

### `draft-advice`
Looks at the specified draft, checks which players have been taken, identifies the user's positional deficits based on their current roster, and recommends the top available rookies.
**Arguments:**
- `--user-id`: The Sleeper User ID.
- `--league-id`: The League ID the draft belongs to.
- `--draft-id`: The Draft ID.
- `--output`: Required. Where to save the JSON output.

## Agent Instructions & Workflow
When the user asks you to check their team, find waivers, or help with a draft:
1. Always run the `fantasy_cli.py` script with `python3` and direct output to a file using the `--output` flag (e.g., `--output /tmp/fantasy_result.json`).
2. Read the resulting JSON file. 
3. **Important:** The script provides algorithmic *recommendations*. You must present these to the user with **added textual context**. Do not just output the raw numbers. Explain *why* a player is a drop (e.g., "He is an old UDFA buried on the depth chart") and why the replacement is better.
4. If the script returns an empty list for waivers, tell the user explicitly that there are no players on the waiver wire who would improve their team. Do not invent wild stashes.

## Rate Limiting
The Sleeper API does not have strict published rate limits, but it enforces IP bans for aggressive scraping.
The `fantasy_cli.py` script automatically respects rate limits by:
- Storing a massive `players.json` database locally in the `resources/` folder. It only fetches the 8000+ players from Sleeper once every 24 hours.
- Adding a mandatory 1-second delay (`time.sleep(1)`) between network calls when fetching rosters and draft picks.
- Implementing automatic retries on 429 errors.

## Common Mistakes
- **Failing to use `--output`:** The output of `fantasy_cli.py` is huge. Always output to a file and parse it.
- **Dropping Theme Players / Stashes:** The algorithm might flag a player as a liability because he scores 0 points, but the user might be holding him intentionally for a theme or specific injury. Always ask the user if they agree with the drop candidates before proceeding.
