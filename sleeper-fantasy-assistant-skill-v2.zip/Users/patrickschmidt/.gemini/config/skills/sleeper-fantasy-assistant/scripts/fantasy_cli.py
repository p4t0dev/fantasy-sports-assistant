#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "urllib3",
# ]
# ///

import argparse
import json
import os
import time
import sys
import urllib.request
from urllib.error import HTTPError, URLError

# Configure paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RESOURCES_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "resources"))

class RateLimitError(Exception):
    pass

def _request(url: str, max_retries: int = 3) -> dict | list:
    """Make HTTP GET request with exponential backoff and rate limit handling."""
    delay = 1
    for attempt in range(max_retries):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req) as response:
                return json.loads(response.read().decode('utf-8'))
        except HTTPError as e:
            if e.code == 429:
                print(f"Rate limit exceeded (HTTP 429) for {url}. Retrying in {delay}s...", file=sys.stderr)
                time.sleep(delay)
                delay *= 2
            elif 500 <= e.code < 600:
                print(f"Server error {e.code} for {url}. Retrying in {delay}s...", file=sys.stderr)
                time.sleep(delay)
                delay *= 2
            else:
                body = e.read().decode('utf-8')
                raise RuntimeError(f"HTTP {e.code} - {e.reason}\nURL: {url}\nResponse: {body}")
        except URLError as e:
            print(f"Network error: {e.reason} for {url}. Retrying in {delay}s...", file=sys.stderr)
            time.sleep(delay)
            delay *= 2
            
    raise RateLimitError(f"Max retries ({max_retries}) exceeded for URL: {url}")

def get_players(sport="nfl", force_refresh=False):
    """Load players from local cache or fetch from Sleeper API if missing/old."""
    os.makedirs(RESOURCES_DIR, exist_ok=True)
    cache_file = os.path.join(RESOURCES_DIR, f"players_{sport}.json")
    
    # Check if cache exists and is fresh (< 24 hours old)
    if not force_refresh and os.path.exists(cache_file):
        file_age = time.time() - os.path.getmtime(cache_file)
        if file_age < 86400: # 24 hours
            try:
                with open(cache_file, "r") as f:
                    return json.load(f)
            except Exception:
                pass
                
    print(f"Fetching {sport.upper()} player data from Sleeper API (this takes a moment)...", file=sys.stderr)
    data = _request(f"https://api.sleeper.app/v1/players/{sport}")
    with open(cache_file, "w") as f:
        json.dump(data, f)
    return data

def get_user(username: str):
    return _request(f"https://api.sleeper.app/v1/user/{username}")

def get_leagues(user_id: str, season: str = "2026", sport: str = "nfl"):
    time.sleep(1) # Rate limit protection
    return _request(f"https://api.sleeper.app/v1/user/{user_id}/leagues/{sport}/{season}")

def get_rosters(league_id: str):
    time.sleep(1)
    return _request(f"https://api.sleeper.app/v1/league/{league_id}/rosters")
    
def get_league(league_id: str):
    time.sleep(1)
    return _request(f"https://api.sleeper.app/v1/league/{league_id}")

def get_draft_picks(draft_id: str):
    time.sleep(1)
    return _request(f"https://api.sleeper.app/v1/draft/{draft_id}/picks")

def _calc_adds_score(player, sport="nfl"):
    """Calculates ADDS Score. Higher means worse."""
    if not player: return 999.0
    age = player.get('age') or (25 if sport == "nfl" else 26)
    rank = player.get('search_rank') or 999999
    
    adds = 0
    if sport == "nfl":
        if age >= 28: adds += 10
        if rank > 1000: adds += 20
        exp = player.get("years_exp") or 0
        if exp == 0 and rank > 500:
            adds += 10 # UDFA penalty
    elif sport == "nba":
        if age >= 32: adds += 10
        if rank > 500: adds += 20
        exp = player.get("years_exp") or 0
        if exp == 0 and rank > 300:
            adds += 10
            
    return adds

def cmd_find_waivers(args):
    user = get_user(args.user_id)
    if not user:
        print(f"User {args.user_id} not found.", file=sys.stderr)
        sys.exit(1)
        
    user_id = user["user_id"]
    
    league = get_league(args.league_id)
    sport = league.get("sport", "nfl")
    print(f"Detected sport: {sport.upper()}", file=sys.stderr)
    
    rosters = get_rosters(args.league_id)
    my_roster = next((r for r in rosters if r["owner_id"] == user_id), None)
    
    if not my_roster:
        print(f"Could not find roster for user {args.user_id} in league {args.league_id}", file=sys.stderr)
        sys.exit(1)
        
    players = get_players(sport=sport)
    taken_player_ids = set()
    for r in rosters:
        if "players" in r and r["players"]:
            taken_player_ids.update(r["players"])
            
    my_players = []
    for pid in my_roster.get("players", []):
        p = players.get(str(pid), {})
        adds = _calc_adds_score(p, sport=sport)
        my_players.append({
            "id": pid,
            "name": f"{p.get('first_name')} {p.get('last_name')}",
            "position": p.get("position"),
            "team": p.get("team"),
            "age": p.get("age"),
            "adds_score": adds,
            "is_liability": adds > 15
        })
        
    valid_positions = ["QB", "RB", "WR", "TE", "K", "DL", "LB", "DB"] if sport == "nfl" else ["PG", "SG", "SF", "PF", "C"]
    
    free_agents = []
    for pid, p in players.items():
        if pid in taken_player_ids: continue
        if p.get("status") not in ["Active", "Injured Reserve", "PUP", None]: continue
        
        # NFL FA team logic vs NBA FA team logic
        if sport == "nfl" and p.get("team") in [None, "FA"]: continue
        if sport == "nba" and p.get("team") is None and p.get("status") != "Active": continue

        # Sometimes sleeper uses multiple fantasy positions, fallback to main position
        pos = p.get("position")
        if not pos and p.get("fantasy_positions"):
            pos = p.get("fantasy_positions")[0]
            
        if pos not in valid_positions: continue
        
        rank = p.get("search_rank") or 999999
        rank_threshold = 1000 if sport == "nfl" else 500
        
        if rank < rank_threshold:
            free_agents.append({
                "id": pid,
                "name": f"{p.get('first_name')} {p.get('last_name')}",
                "position": pos,
                "team": p.get("team"),
                "age": p.get("age"),
                "rank": rank
            })
            
    free_agents.sort(key=lambda x: x["rank"])
    
    result = {
        "league_id": args.league_id,
        "sport": sport,
        "liabilities_to_drop": [p for p in my_players if p["is_liability"]],
        "all_roster": sorted(my_players, key=lambda x: x["adds_score"], reverse=True),
        "top_free_agents": free_agents[:15]
    }
    
    with open(args.output, "w") as f:
        json.dump(result, f, indent=2)
    print(f"Success! Analysis written to: {args.output}")

def cmd_draft_advice(args):
    league = get_league(args.league_id)
    sport = league.get("sport", "nfl")
    print(f"Detected sport: {sport.upper()}", file=sys.stderr)
    
    players = get_players(sport=sport)
    draft = _request(f"https://api.sleeper.app/v1/draft/{args.draft_id}")
    picks = get_draft_picks(args.draft_id)
    
    picked_ids = {str(p.get("player_id")) for p in picks}
    
    available_rookies = []
    for pid, p in players.items():
        if pid in picked_ids: continue
        years = p.get("years_exp") or 0
        if years == 0 and p.get("status") in ["Active", "Injured Reserve", "PUP", None]:
            rank = p.get("search_rank") or 999999
            pos = p.get("position")
            if not pos and p.get("fantasy_positions"):
                pos = p.get("fantasy_positions")[0]
                
            available_rookies.append({
                "id": pid,
                "name": f"{p.get('first_name')} {p.get('last_name')}",
                "position": pos,
                "team": p.get("team"),
                "rank": rank
            })
            
    available_rookies.sort(key=lambda x: x["rank"])
    
    result = {
        "draft_status": draft.get("status"),
        "sport": sport,
        "last_5_picks": [{"pick": p.get("pick_no"), "id": p.get("player_id")} for p in picks[-5:]] if picks else [],
        "top_available_rookies": available_rookies[:20]
    }
    
    with open(args.output, "w") as f:
        json.dump(result, f, indent=2)
    print(f"Success! Draft advice written to: {args.output}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Sleeper Fantasy Assistant CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # find-waivers
    parser_fw = subparsers.add_parser("find-waivers")
    parser_fw.add_argument("--user-id", required=True)
    parser_fw.add_argument("--league-id", required=True)
    parser_fw.add_argument("--output", required=True)

    # draft-advice
    parser_da = subparsers.add_parser("draft-advice")
    parser_da.add_argument("--user-id", required=True)
    parser_da.add_argument("--league-id", required=True)
    parser_da.add_argument("--draft-id", required=True)
    parser_da.add_argument("--output", required=True)

    args = parser.parse_args()

    try:
        if args.command == "find-waivers":
            cmd_find_waivers(args)
        elif args.command == "draft-advice":
            cmd_draft_advice(args)
    except Exception as e:
        print(f"Error executing {args.command}: {e}", file=sys.stderr)
        sys.exit(1)
